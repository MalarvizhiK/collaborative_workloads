'use strict';
var inquirer = require('inquirer');
var moment = require('moment');

const BusinessNetworkConnection = require('composer-client').BusinessNetworkConnection;
const Table = require('cli-table');
const winston = require('winston');
let config = require('config');

let participantProviderClass = 'collaborativeworkloads.workloadmodel.InsightProvider';
let participantWlOwnerClass = 'collaborativeworkloads.workloadmodel.WorkloadOwner';
let assetWLoadClass = 'collaborativeworkloads.workloadmodel.Workload';
let assetITExpClass = 'collaborativeworkloads.monitoring.ITExperience';
let ns = 'collaborativeworkloads.workloadmodel';
let nsmonitoring = 'collaborativeworkloads.monitoring';
let insightProvider = 'InsightProvider';
let workloadOwner = 'WorkloadOwner';
let workload = 'Workload';
let data = 'MonitoredData';

// This function adds ITExperience Data and it will add to Asset Workload

console.log('Hi, Welcome to Collaborative Workloads. Adding ITExperienceData');

var questions = [
  {
    type: 'input',
    name: 'cardname',
    message: 'Workload Owner cardname?'
  },
  {
  type: 'input',
    name: 'numberOfCrashes',
    message: 'Number of Crashes?'
  },
  {
  type: 'input',
    name: 'startDate',
    message: 'Start Date(YYYY/mm/dd)(2018/02/29)?'
  },
  {
  type: 'input',
    name: 'endDate',
    message: 'End Date(YYYY/mm/dd)(2018/02/29)?'
  }  
  ];

inquirer.prompt(questions).then(answers => {

this.bizNetworkConnection = new BusinessNetworkConnection();
this.bizNetworkConnection.connect(answers.cardname)
.then((result) => {
  this.businessNetworkDefinition = result;    
  var index = answers.cardname.indexOf("@");
  var ownerVar =answers.cardname.substring(0,index);
  
  let factory = this.businessNetworkDefinition.getFactory();       
  let wLoadRegistry = this.bizNetworkConnection.getAssetRegistry(assetWLoadClass); 
  
  let data1 = factory.newConcept(nsmonitoring, data);
  data1.numberOfCrashes=parseInt(answers.numberOfCrashes);
    
  //data1.start = new Date(2018, 2, 10);
  //data1.end = new Date(2018, 2, 11);
  
  var start = (answers.startDate).split("/");
  var end = (answers.endDate).split("/");
  data1.start = new Date (start[0], start[1]-1, start[2]);
  data1.end = new Date(end[0], end[1]-1, end[2])
  
  var workloadVar ;
  var itExpVar;
  
  this.bizNetworkConnection.getParticipantRegistry(participantWlOwnerClass).then((wlOwnerRegistry) => {
		let itexp1 ;
		  wlOwnerRegistry.get(ownerVar).then((wlOwner) => {
			workloadVar = wlOwner.workload.assetId;
			return workloadVar;
			}).then((workloadVar) => {
				this.bizNetworkConnection.getAssetRegistry(assetITExpClass).then((itexpRegistry) => {
					if (workloadVar.indexOf("WorkloadA") >= 0)
						itExpVar = "ITExperienceA" + new Date().getTime();
					else
						itExpVar = "ITExperienceB" + new Date().getTime();
					itexp1 = factory.newResource(nsmonitoring, 'ITExperience', itExpVar);
					itexp1.workload = factory.newRelationship('collaborativeworkloads.workloadmodel', 'Workload',workloadVar);				
					itexp1.data = [data1];
					itexpRegistry.add(itexp1);
					console.log("Added " + itExpVar);  
				});
				
				this.bizNetworkConnection.getAssetRegistry(assetWLoadClass).then((wloadRegistry) => {
					wloadRegistry.get(workloadVar).then((wLoad) => {
					//let workloadA = factory.newResource('collaborativeworkloads.workloadmodel', 'Workload',workloadVar);
					if (typeof wLoad.data == 'undefined')
						wLoad.data = [itexp1];
					else
						wLoad.data.push(itexp1);

					return wloadRegistry.update(wLoad);
					});					
			});
	});
});		
});
});