'use strict';
var inquirer = require('inquirer');

const BusinessNetworkConnection = require('composer-client').BusinessNetworkConnection;
const Table = require('cli-table');
const winston = require('winston');
let config = require('config');

let participantProviderClass = 'collaborativeworkloads.workloadmodel.InsightProvider';
let participantWlOwnerClass = 'collaborativeworkloads.workloadmodel.WorkloadOwner';
let assetWLoadClass = 'collaborativeworkloads.workloadmodel.Workload';
let assetRequestsListingClass = 'collaborativeworkloads.workloadmodel.RequestsListing';
let assetITExpClass = 'collaborativeworkloads.monitoring.ITExperience';
let ns = 'collaborativeworkloads.workloadmodel';
let nsmonitoring = 'collaborativeworkloads.monitoring';
let insightProvider = 'InsightProvider';
let workloadOwner = 'WorkloadOwner';
let workload = 'Workload';
let requests = 'Requests';

// This function request access to Workload

console.log('Hi, Welcome to Collaborative Workloads. Request access to workload.');

var questions = [
  {
    type: 'input',
    name: 'cardname',
    message: 'Insight Provider cardname?'
  },
  {
  type: 'input',
    name: 'workload',
    message: 'workload?'
  }
  ];

inquirer.prompt(questions).then(answers => {

this.bizNetworkConnection = new BusinessNetworkConnection();
this.bizNetworkConnection.connect(answers.cardname)
.then((result) => {
  this.businessNetworkDefinition = result;    
	 let factory = this.businessNetworkDefinition.getFactory();       
	 let rListingRegistry = this.bizNetworkConnection.getAssetRegistry(assetRequestsListingClass);	
	 
	 var providerVar ;
	 var requestListingVar; 
	 var index = answers.cardname.indexOf("@");
	 providerVar =answers.cardname.substring(0,index);
	 		
	if (answers.workload == "WorkloadA")	
		requestListingVar = 'RequestsListingA';
	else
		requestListingVar = 'RequestsListingB';
		
	 let workloadA = factory.newResource(ns, 'Workload', answers.workload);
	 let providerA = factory.newResource(ns, 'InsightProvider', providerVar);
	 providerA.organisation = providerVar;
			
	 let requests1 = factory.newConcept(ns, requests);
	 requests1.workload = workloadA;
	 requests1.provider = providerA;
	 	
	 let listing = factory.newResource(ns, 'RequestsListing', requestListingVar);
	 listing.requests = [requests1];
	 this.bizNetworkConnection.getAssetRegistry(assetRequestsListingClass).then((requestsRegistry) => {
	 
		requestsRegistry.get(requestListingVar).then((listing) => {
			if (typeof listing.requests == 'undefined')
				listing.requests = [requests1];
			else
				listing.requests.push(requests1);
						
			return requestsRegistry.update(listing);
			});
		});
     	
});
});