'use strict';
var inquirer = require('inquirer');

const BusinessNetworkConnection = require('composer-client').BusinessNetworkConnection;
const Table = require('cli-table');
const winston = require('winston');
let config = require('config');

let participantProviderClass = 'collaborativeworkloads.workloadmodel.InsightProvider';
let participantWlOwnerClass = 'collaborativeworkloads.workloadmodel.WorkloadOwner';
let assetWLoadClass = 'collaborativeworkloads.workloadmodel.Workload';
let assetITExpClass = 'collaborativeworkloads.monitoring.ITExperience';
let ns = 'collaborativeworkloads.workloadmodel';
let nsmonitoring = 'collaborativeworkloads.monitoring';
let insightProvider = 'InsightProvider';
let workloadOwner = 'WorkloadOwner';
let workload = 'Workload';
let data = 'MonitoredData';

// This function retrieves ITExperience Data 

console.log('Hi, Welcome to Collaborative Workloads. Retrieves ITExperienceData');

var questions = [
  {
    type: 'input',
    name: 'cardname',
    message: 'Insight Provider cardname?'
  },
  {
    type: 'input',
    name: 'workload',
    message: 'Workload?'
  }
  ];

inquirer.prompt(questions).then(answers => {

var index = answers.cardname.indexOf("@");
var providerVar =answers.cardname.substring(0,index);


this.bizNetworkConnection = new BusinessNetworkConnection();
this.bizNetworkConnection.connect(answers.cardname)
.then((result) => {
  this.businessNetworkDefinition = result;    
	 let factory = this.businessNetworkDefinition.getFactory();       
	 let wLoadRegistry = this.bizNetworkConnection.getAssetRegistry(assetWLoadClass);	
			
		this.bizNetworkConnection.getAssetRegistry(assetWLoadClass).then((wloadRegistry) => {
			wloadRegistry.get(answers.workload).then((wLoad) => {
					var len = wLoad.providers.length;
					if (len == 0)
					{
						console.log("No data");
						process.exit();
					}
					else
					{					
						var i=0;
						while (i < len)
						{
							if (wLoad.providers[i].providerId == providerVar)
							{
								var wLoadLen = wLoad.data.length;
								var j = 0;
								while (j < wLoadLen)
								{
									console.log("-------------------------------------");
									console.log("ITExperience Data " + (j+1));
									console.log("Number Of Crashes " + wLoad.data[j].data[0].numberOfCrashes);
									console.log("Start Date " + wLoad.data[j].data[0].start);
									console.log("End date " + wLoad.data[j].data[0].end);
									console.log("-------------------------------------");
									j++;
								}
							}
							i++;
						}
					}
			}).catch(function (error) {
				console.log("No data");
			});	
	});	
});
});