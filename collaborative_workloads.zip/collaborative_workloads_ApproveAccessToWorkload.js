'use strict';
var inquirer = require('inquirer');

const BusinessNetworkConnection = require('composer-client').BusinessNetworkConnection;
const Table = require('cli-table');
const winston = require('winston');
let config = require('config');

let participantProviderClass = 'collaborativeworkloads.workloadmodel.InsightProvider';
let participantWlOwnerClass = 'collaborativeworkloads.workloadmodel.WorkloadOwner';
let assetWLoadClass = 'collaborativeworkloads.workloadmodel.Workload';
let assetRequestsListingClass = 'collaborativeworkloads.workloadmodel.RequestsListing';
let assetITExpClass = 'collaborativeworkloads.monitoring.ITExperience';
let ns = 'collaborativeworkloads.workloadmodel';
let nsmonitoring = 'collaborativeworkloads.monitoring';
let insightProvider = 'InsightProvider';
let workloadOwner = 'WorkloadOwner';
let workload = 'Workload';
let requests = 'Requests';

// This function approve access to Insight Provider

console.log('Hi, Welcome to Collaborative Workloads. Approve access to insight provider.');

var questions = [
  {
    type: 'input',
    name: 'cardname',
    message: 'Workload Owner cardname?'
  }
  ];

inquirer.prompt(questions).then(answers => {

this.bizNetworkConnection = new BusinessNetworkConnection();
this.bizNetworkConnection.connect(answers.cardname)
.then((result) => {
  this.businessNetworkDefinition = result;    
	 let factory = this.businessNetworkDefinition.getFactory();       
	 let rListingRegistry = this.bizNetworkConnection.getAssetRegistry(assetRequestsListingClass);	
	 let wloadRegistry = this.bizNetworkConnection.getAssetRegistry(assetWLoadClass);	
	 
	 var listingVar ;
	 var providerList=[];
	 var requestListing;
	 var assetId ;
	 if (answers.cardname == "WorkloadOwnerA@collaborative-workloads")
		listingVar = 'RequestsListingA';
	else
		listingVar = 'RequestsListingB';
	 this.bizNetworkConnection.getAssetRegistry(assetRequestsListingClass).then((requestsRegistry) => {
          requestsRegistry.get(listingVar).then((requestListing) => {
			var len = requestListing.requests.length;
			
			if (len == 0)
			{
				console.log("No data");
				process.exit();
			}	
						
			var i = 0;
			while (i < len)
			{
				var req = requestListing.requests[i];
				
				assetId = req.workload.assetId;
				var providerId = req.provider;
				providerList[i] = providerId;
				i++;
			}
			return requestListing;
			}).then((requestListing) => {
				this.bizNetworkConnection.getAssetRegistry(assetWLoadClass).then((wloadRegistry) => {
					wloadRegistry.get(assetId).then((wLoad) => {
						var lenj = providerList.length;
						var j = 0;
							
						while (j < lenj)
						{						
							if ((typeof wLoad.providers == 'undefined') && (j ==0))
								wLoad.providers = [providerList[0]];
							else
								wLoad.providers.push(providerList[j]);
													
							wloadRegistry.update(wLoad);
							
							j++;
						}
					});
						
				});	
				return requestListing;
			}).then((requestListing) => {
				requestListing.requests = [];
				
				this.bizNetworkConnection.getAssetRegistry(assetRequestsListingClass).then((listingRegistry) => {
					return listingRegistry.update(requestListing);
				});		
			
				
			});
	});
});
});